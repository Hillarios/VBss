﻿


Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PictureBox1.Visible = False
        PictureBox2.Visible = False

    End Sub

    Private Sub btnveggie_Click(sender As Object, e As EventArgs) Handles btnveggie.Click
        PictureBox2.Visible = False
        PictureBox1.Visible = True
    End Sub

    Private Sub btnexit_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        Application.Exit()
    End Sub

    Private Sub btnprbeef_Click(sender As Object, e As EventArgs) Handles btnprbeef.Click
        PictureBox1.Visible = False
        PictureBox2.Visible = True
    End Sub

    Private Sub btnselectedmeal_Click(sender As Object, e As EventArgs) Handles btnselectedmeal.Click

        If PictureBox1.Visible = True Then
            txtone.Text = "Enjoy your prime bugger"
        Else
            PictureBox2.Visible = True
            txtone.Text = "Enjoy your veggie bugger"
        End If

    End Sub




End Class