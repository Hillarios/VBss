﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnprbeef = New System.Windows.Forms.Button()
        Me.btnselectedmeal = New System.Windows.Forms.Button()
        Me.btnveggie = New System.Windows.Forms.Button()
        Me.btnexit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtone = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnprbeef
        '
        Me.btnprbeef.BackColor = System.Drawing.Color.Wheat
        Me.btnprbeef.DialogResult = System.Windows.Forms.DialogResult.Ignore
        Me.btnprbeef.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnprbeef.ForeColor = System.Drawing.Color.Black
        Me.btnprbeef.Location = New System.Drawing.Point(101, 385)
        Me.btnprbeef.Name = "btnprbeef"
        Me.btnprbeef.Size = New System.Drawing.Size(130, 40)
        Me.btnprbeef.TabIndex = 0
        Me.btnprbeef.Text = "Prime Beef"
        Me.btnprbeef.UseVisualStyleBackColor = False
        '
        'btnselectedmeal
        '
        Me.btnselectedmeal.BackColor = System.Drawing.Color.Wheat
        Me.btnselectedmeal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnselectedmeal.ForeColor = System.Drawing.Color.Red
        Me.btnselectedmeal.Location = New System.Drawing.Point(310, 385)
        Me.btnselectedmeal.Name = "btnselectedmeal"
        Me.btnselectedmeal.Size = New System.Drawing.Size(157, 40)
        Me.btnselectedmeal.TabIndex = 1
        Me.btnselectedmeal.Text = "Selected Meal"
        Me.btnselectedmeal.UseVisualStyleBackColor = False
        '
        'btnveggie
        '
        Me.btnveggie.BackColor = System.Drawing.Color.Wheat
        Me.btnveggie.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnveggie.ForeColor = System.Drawing.Color.Black
        Me.btnveggie.Location = New System.Drawing.Point(543, 385)
        Me.btnveggie.Name = "btnveggie"
        Me.btnveggie.Size = New System.Drawing.Size(130, 40)
        Me.btnveggie.TabIndex = 2
        Me.btnveggie.Text = "Veggie"
        Me.btnveggie.UseVisualStyleBackColor = False
        '
        'btnexit
        '
        Me.btnexit.BackColor = System.Drawing.Color.Wheat
        Me.btnexit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.ForeColor = System.Drawing.Color.Red
        Me.btnexit.Location = New System.Drawing.Point(310, 507)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(130, 40)
        Me.btnexit.TabIndex = 3
        Me.btnexit.Text = "Exit Window"
        Me.btnexit.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(267, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(233, 25)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Farm Burger Specials"
        '
        'txtone
        '
        Me.txtone.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtone.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtone.Location = New System.Drawing.Point(226, 459)
        Me.txtone.Name = "txtone"
        Me.txtone.Size = New System.Drawing.Size(326, 14)
        Me.txtone.TabIndex = 7
        Me.txtone.Text = "choose a bugger and then click selected meal button"
        Me.txtone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.WindowsApp1.My.Resources.Resources.images__2_
        Me.PictureBox1.Location = New System.Drawing.Point(422, 103)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(227, 235)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 8
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.WindowsApp1.My.Resources.Resources.Santa_Fe_Veggie_Burgers_with_Sweet_Potato_Fries_and_Chipotle_Ketchup3
        Me.PictureBox2.Location = New System.Drawing.Point(128, 97)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(226, 241)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 9
        Me.PictureBox2.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FloralWhite
        Me.ClientSize = New System.Drawing.Size(800, 578)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.txtone)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnexit)
        Me.Controls.Add(Me.btnveggie)
        Me.Controls.Add(Me.btnselectedmeal)
        Me.Controls.Add(Me.btnprbeef)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnprbeef As Button
    Friend WithEvents btnselectedmeal As Button
    Friend WithEvents btnveggie As Button
    Friend WithEvents btnexit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txtone As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
End Class
